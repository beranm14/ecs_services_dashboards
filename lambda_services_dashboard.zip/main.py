import json
import boto3
import logging
import os
from jinja2 import Environment, FileSystemLoader


session = boto3.session.Session()
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    cluster_name = os.environ.get('ECS_CLUSTER')
    ecs_region_name = os.environ.get('ECS_REGION_NAME') if \
        os.environ.get('ECS_REGION_NAME') else 'eu-west-1'

    ecs = session.client(
        service_name='ecs',
        region_name=ecs_region_name
    )
    clw = session.client(
        service_name='cloudwatch',
        region_name=ecs_region_name
    )
    elb = boto3.client(
        service_name='elbv2',
        region_name=ecs_region_name
    )

    templates_dir = './templates'
    env = Environment(loader=FileSystemLoader(templates_dir))
    template = env.get_template('dashboard.json.j2')

    services = ecs.list_services(
        cluster=cluster_name
    )
    dashboards = clw.list_dashboards()

    services_names = [
        service.split("/")[1] for service in services['serviceArns']
    ]
    dashboards_names = [
        dashboard['DashboardName'] for dashboard in dashboards['DashboardEntries']
    ]

    target_groups = elb.describe_target_groups(
        Names=services_names
    )['TargetGroups']

    template_data_list = []

    y_counter = 0

    for service in services_names:
        target_group = [
            tg['TargetGroupArn'].split('/')[-1] for tg in target_groups if tg['TargetGroupName'] == service
        ][0]
        template_data_list += [
            {
                "target_group_id": target_group,
                "ecs_cluster_name": cluster_name,
                "ecs_service": service,
                "region": ecs_region_name,
                "y": y_counter
            }
        ]
        y_counter += 1

    dashboard_body = template.render(
        template_data_list=template_data_list
    )
    clw.put_dashboard(
        DashboardName=cluster_name + "-ecs-services-list-dashboard",
        DashboardBody=dashboard_body
    )


    return {
        "statusCode": 200,
        "body": json.dumps('Ended correctly')
    }


if __name__ == "__main__":
    lambda_handler("", "")
